from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
import requests
app = FastAPI()
import json
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

url = "https://api.groq.com/openai/v1/chat/completions"
@app.post("/generatePost/")
async def generatePost(request: Request):
    res = await request.json()
    topic = res["topic"]
]
    payload = json.dumps({
            "messages": [
                {
                "role": "system",
                "content": "You are a helpful assistant."
                },
                {
                "role": "user",
                "content": topic,
                }
            ],
            "model": "llama-3.3-70b-versatile"
        })
    headers = {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer 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',
    'Cookie': '__cf_bm=UlZIjBpuENOu1yXaVGL3bFY7dUq15akKNfSBHpZHzV8-1749391472-1.0.1.1-CXXVLKbyX0dAo4jvha9JEDJWB7BPqwOi.FhYCvPuYiPCc9zUdTaeB.wF954YxkW0qDC9eCTa4sbBpMwg2t4IAmREyYuJSGZ5Bde2Y1loALA'
    }

    response = requests.request("POST", url, headers=headers, data=payload)
    data = response.json()
    res = data['choices'][0]['message']['content']

    return {"post": res}












